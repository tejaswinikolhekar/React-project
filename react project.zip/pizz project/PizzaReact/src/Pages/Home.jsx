import React from 'react'
import Herose from '../Components/Herose'
import PizzaColl from '../Components/PizzaColl'

export default function Home() {
  return (
  <div>
    <Herose/>
    <hr />
    <PizzaColl/>
  </div>
  )
}
